
package modelo;


public class Window extends Producto{
    
    public Window(int id, String name, String dimension, String material) {
        super(id, name, dimension, material);
    }
    
}
